cat << EOF > /home/phaedrus/Forge/GH/Qompass/WaveRunner/NVIDIA/OpenBLAS/README.md
# Qompass OpenBLAS Release

Version: 0.3.28.dev, compiled on Arch Linux machine with x86_64 processor

## Build Instructions

1. Clone the OpenBLAS repository:
   \`\`\`
   git clone https://github.com/xianyi/OpenBLAS.git
   cd OpenBLAS
   \`\`\`

2. Build OpenBLAS:
   \`\`\`
   make TARGET=HASWELL USE_OPENMP=1
   \`\`\`

3. Install OpenBLAS:
   \`\`\`
   sudo make PREFIX=/usr/local install
   \`\`\`

## Notes

- This build was optimized for Intel Haswell architecture.
- OpenMP support is enabled for multi-threading.
- The library is installed in /usr/local/lib and headers in /usr/local/include.

EOF

